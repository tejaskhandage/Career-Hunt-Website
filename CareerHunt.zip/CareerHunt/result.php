<!DOCTYPE html>
<html>

<head>
	<title>Career Hunt</title>
	
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="keywords" content="Conceit Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
	<script type="application/x-javascript">
		addEventListener("load", function () {
			setTimeout(hideURLbar, 0);
		}, false);

		function hideURLbar() {
			window.scrollTo(0, 1);
		}
	</script>
	<!--//tags -->
	<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
	<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
	<link href="css/team.css" rel="stylesheet" type="text/css" media="all" />
	<link href="css/prettyPhoto.css" rel="stylesheet" type="text/css" />
	<link href="css/font-awesome.css" rel="stylesheet">

	<link href="//fonts.googleapis.com/css?family=Raleway:100,100i,200,300,300i,400,400i,500,500i,600,600i,700,800" rel="stylesheet">
	<link href="//fonts.googleapis.com/css?family=Source+Sans+Pro:300,300i,400,400i,600,600i,700" rel="stylesheet">
</head>

<body>
	<div class="top_header" id="home">
		<!-- Fixed navbar -->
		<nav class="navbar navbar-default navbar-fixed-top">
			<div class="nav_top_fx_w3ls_agileinfo">
				<div class="navbar-header">
					<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false"
					    aria-controls="navbar">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
					<div class="logo-w3layouts-agileits">
						<h1> <a class="navbar-brand" href="index.html"><i class="fa fa-clone" aria-hidden="true"></i>  Career<span class="desc">Hunt</span></a></h1>
					</div>
				</div>
				<div id="navbar" class="navbar-collapse collapse">
				
						<div class="nav_right_top">
							<ul class="nav navbar-nav navbar-right">
                            <li><a class="request btn btn-danger" href="logout.php">Logout</a></li>
	
							</ul>
							<ul class="nav navbar-nav">
								<li><a href="index.html">Home</a></li>
								<li><a href="about.html">About</a></li>
								<li><a href="guidance.html">Guidance</a></li>
								<li  ><a href="portfolio.html">Team</a></li>
								<li ><a href="FAQ.php">FAQ/Comments</a></li>
								<li><a href="contact.html">Contact</a></li>
								<li class="active "><a href="UserPanel.php">Test</a></li>
								
							</ul>
						</div>
					
				</div>
				<!--/.nav-collapse -->
			</div>
		</nav>
	</div>
	<!--/banner_info-->
	<div class="banner_inner_con">
	</div>
	<div class="services-breadcrumb">
		<div class="inner_breadcrumb">

			<ul class="short">
				<li><a href="index.html">Home</a><span>|</span></li>
				<li>Test 2</li>
			</ul>
		</div>
	</div>
	<!--//banner_info-->

    <br><br><h2>Your Career Interests</h2>
<p>This section shows your top career interest areas. <br>There are a total of 6 such interest areas, each one having its own set of unique work tasks, roles, skills, and values. Some of these interest areas will appeal to you, while others will be less attractive. <br>Making sure that you choose the right career option is vital as it will make sure that you enjoy daily work and get satisfaction out of your accomplishments.<br><br></p><center><table cellspacing='0' cellpadding='0' border='0' width='50%'><tr>
			<td align='right' width='25%' height='50px'><b><big>Social</big></b>&nbsp;</td>
			<td width='5%'></td>
			<td width='70%'>
			<table border = '0' width = '100%' cellpadding = '1' cellspacing='1'>
			<tr><td align='left' bgcolor='#E2F0CB' width='46%' height='50px'></td>
			     <td align='left'><?php echo(rand(10,100)); ?>%</td>
			   </tr>
			</table>
		</td>
			</tr><tr>
			<td align='right' width='25%' height='50px'><b><big>Enterprising</big></b>&nbsp;</td>
			<td width='5%'></td>
			<td width='70%'>
			<table border = '0' width = '100%' cellpadding = '1' cellspacing='1'>
			<tr><td align='left' bgcolor='#B5EAD7' width='46%' height='50px'></td>
			     <td align='left'><?php echo(rand(10,100)); ?></td>
			   </tr>
			</table>
		</td>
			</tr><tr>
			<td align='right' width='25%' height='50px'><b><big>Artistic</big></b>&nbsp;</td>
			<td width='5%'></td>
			<td width='70%'>
			<table border = '0' width = '100%' cellpadding = '1' cellspacing='1'>
			<tr><td align='left' bgcolor='#F9EDC3' width='42%' height='50px'></td>
			     <td align='left'><?php echo(rand(10,100)); ?></td>
			   </tr>
			</table>
		</td>
			</tr><tr>
			<td align='right' width='25%' height='50px'><b><big>Conventional</big></b>&nbsp;</td>
			<td width='5%'></td>
			<td width='70%'>
			<table border = '0' width = '100%' cellpadding = '1' cellspacing='1'>
			<tr><td align='left' bgcolor='#C7CEEA' width='42%' height='50px'></td>
			     <td align='left'><?php echo(rand(10,100)); ?></td>
			   </tr>
			</table>
		</td>
			</tr><tr>
			<td align='right' width='25%' height='50px'><b><big>Realistic</big></b>&nbsp;</td>
			<td width='5%'></td>
			<td width='70%'>
			<table border = '0' width = '100%' cellpadding = '1' cellspacing='1'>
			<tr><td align='left' bgcolor='#FF9AA2' width='38%' height='50px'></td>
			     <td align='left'><?php echo(rand(10,100)); ?></td>
			   </tr>
			</table>
		</td>
			</tr><tr>
			<td align='right' width='25%' height='50px'><b><big>Investigative</big></b>&nbsp;</td>
			<td width='5%'></td>
			<td width='70%'>
			<table border = '0' width = '100%' cellpadding = '1' cellspacing='1'>
			<tr><td align='left' bgcolor='#FFDAC1' width='38%' height='50px'></td>
			     <td align='left'><?php echo(rand(10,100)); ?></td>
			   </tr>
			</table>
		</td>
			</tr></table></center><br><center><big><p>Your primary traits are Social, Enterprising.</p></big></center><br><br><!--DOCTYPE HTML>
<html>

		<!-- footer -->
		<div class="footer">
			<div class="footer_inner_info_w3ls_agileits">
				<div class="col-md-3 footer-left">
					<h2><a href="index.html"><i class="fa fa-clone" aria-hidden="true"></i> Career Hunt </a></h2>
					<p>Lorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora.</p>
					<ul class="social-nav model-3d-0 footer-social social two">
						<li>
							<a href="#" class="facebook">
								<div class="front"><i class="fa fa-facebook" aria-hidden="true"></i></div>
								<div class="back"><i class="fa fa-facebook" aria-hidden="true"></i></div>
							</a>
						</li>
						<li>
							<a href="#" class="twitter">
								<div class="front"><i class="fa fa-twitter" aria-hidden="true"></i></div>
								<div class="back"><i class="fa fa-twitter" aria-hidden="true"></i></div>
							</a>
						</li>
						<li>
							<a href="#" class="instagram">
								<div class="front"><i class="fa fa-instagram" aria-hidden="true"></i></div>
								<div class="back"><i class="fa fa-instagram" aria-hidden="true"></i></div>
							</a>
						</li>
						<li>
							<a href="#" class="pinterest">
								<div class="front"><i class="fa fa-linkedin" aria-hidden="true"></i></div>
								<div class="back"><i class="fa fa-linkedin" aria-hidden="true"></i></div>
							</a>
						</li>
					</ul>
				</div>
				<div class="col-md-9 footer-right">
					<div class="sign-grds">
					
					
						<div class="col-md-5 sign-gd-two">
							<h4>Contact <span>Information</span></h4>
							<div class="address">
								<div class="address-grid">
									<div class="address-left">
										<i class="fa fa-phone" aria-hidden="true"></i>
									</div>
									<div class="address-right">
										<h6>Phone Number</h6>
										<p>+91 93707 18105</p>
									</div>
									<div class="clearfix"> </div>
								</div>
								<div class="address-grid">
									<div class="address-left">
										<i class="fa fa-envelope" aria-hidden="true"></i>
									</div>
									<div class="address-right">
										<h6>Email Address</h6>
										<p>Email :<a href="mailto:tejaskhandage@gmail.com"> tejaskhandage@gmail.com</a></p>
									</div>
									<div class="clearfix"> </div>
								</div>
								<div class="address-grid">
									<div class="address-left">
										<i class="fa fa-map-marker" aria-hidden="true"></i>
									</div>
									<div class="address-right">
										<h6>Location</h6>
										<p>Jaihind Polytechnic Kuran
	
										</p>
									</div>
									<div class="clearfix"> </div>
								</div>
							</div>
						</div>
	
						<div class="clearfix"></div>
					</div>
				</div>
				<div class="clearfix"></div>
				<p class="copy-right">Design by : Tejas Vikas Khandage</p>
			</div>
		</div>
		</div>
		<!-- //footer -->
	<!-- //footer -->
	<script type="text/javascript" src="js/jquery-2.2.3.min.js"></script>
	<script type="text/javascript" src="js/bootstrap.js"></script>
	<script>
		$('ul.dropdown-menu li').hover(function () {
			$(this).find('.dropdown-menu').stop(true, true).delay(200).fadeIn(500);
		}, function () {
			$(this).find('.dropdown-menu').stop(true, true).delay(200).fadeOut(500);
		});
	</script>

	<!-- js -->
	<!-- Smooth-Scrolling-JavaScript -->
	<script type="text/javascript" src="js/easing.js"></script>
	<script type="text/javascript" src="js/move-top.js"></script>
	<script type="text/javascript">
		jQuery(document).ready(function ($) {
			$(".scroll, .navbar li a, .footer li a").click(function (event) {
				$('html,body').animate({
					scrollTop: $(this.hash).offset().top
				}, 1000);
			});
		});
	</script>
	<!-- //Smooth-Scrolling-JavaScript -->
	<script type="text/javascript">
		$(document).ready(function () {
		

			$().UItoTop({
				easingType: 'easeOutQuart'
			});

		});
	</script>
	<a href="#home" class="scroll" id="toTop" style="display: block;"> <span id="toTopHover" style="opacity: 1;"> </span></a>
	<!-- jQuery-Photo-filter-lightbox-Gallery-plugin -->
	<script type="text/javascript" src="js/jquery-1.7.2.js"></script>
	<script src="js/jquery.quicksand.js" type="text/javascript"></script>
	<script src="js/script.js" type="text/javascript"></script>
	<script src="js/jquery.prettyPhoto.js" type="text/javascript"></script>
	<!-- //jQuery-Photo-filter-lightbox-Gallery-plugin -->
</body>

</html>
<!DOCTYPE html>
<html>

<head>
	<title>Career Hunt</title>
	
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="keywords" content="Conceit Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
	<script type="application/x-javascript">
		addEventListener("load", function () {
			setTimeout(hideURLbar, 0);
		}, false);

		function hideURLbar() {
			window.scrollTo(0, 1);
		}
	</script>
	<!--//tags -->
	<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
	<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
	<link href="css/team.css" rel="stylesheet" type="text/css" media="all" />
	<link href="css/prettyPhoto.css" rel="stylesheet" type="text/css" />
	<link href="css/font-awesome.css" rel="stylesheet">

	<link href="//fonts.googleapis.com/css?family=Raleway:100,100i,200,300,300i,400,400i,500,500i,600,600i,700,800" rel="stylesheet">
	<link href="//fonts.googleapis.com/css?family=Source+Sans+Pro:300,300i,400,400i,600,600i,700" rel="stylesheet">
</head>

<body>
	<div class="top_header" id="home">
		<!-- Fixed navbar -->
		<nav class="navbar navbar-default navbar-fixed-top">
			<div class="nav_top_fx_w3ls_agileinfo">
				<div class="navbar-header">
					<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false"
					    aria-controls="navbar">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
					<div class="logo-w3layouts-agileits">
						<h1> <a class="navbar-brand" href="index.html"><i class="fa fa-clone" aria-hidden="true"></i>  Career<span class="desc">Hunt</span></a></h1>
					</div>
				</div>
				<div id="navbar" class="navbar-collapse collapse">
				
						<div class="nav_right_top">
							<ul class="nav navbar-nav navbar-right">
								<li><a class="request btn btn-success" href="signin.php">Login</a></li>
	
							</ul>
							<ul class="nav navbar-nav">
								<li><a href="index.html">Home</a></li>
								<li><a href="about.html">About</a></li>
								<li><a href="guidance.html">Guidance</a></li>
								<li  ><a href="portfolio.html">Team</a></li>
								<li ><a href="FAQ.php">FAQ/Comments</a></li>
								<li><a href="contact.html">Contact</a></li>
								<li class="active "><a href="test.html">Test</a></li>
								
							</ul>
						</div>
					
				</div>
				<!--/.nav-collapse -->
			</div>
		</nav>
	</div>
	<!--/banner_info-->
	<div class="banner_inner_con">
	</div>
	<div class="services-breadcrumb">
		<div class="inner_breadcrumb">

			<ul class="short">
				<li><a href="index.html">Home</a><span>|</span></li>
				<li>Test</li>
			</ul>
		</div>
	</div>
	<!--//banner_info-->

    <form method="POST" action="result.php">

	<input type="hidden" name="unqid" value="5c8b5e3baef44" />
	<input type="hidden" name="seconds" value="1552637509" />
	<input type="hidden" name="onblurs" value="0" />
	
	<table id="page1" width="600px" align="center" cellspacing="0" cellpadding="5">
	<tr>
	<td width="350px" />
	<td width="50px" align="center"><big>Dislike</big></td>
	<td width="50px"/>
	<td width="50px"><big>Neutral</big></td>
	<td width="50px"/>
	<td width="50px" align="center"><big>Enjoy</big></td>
	</tr>

	
	
	<tr style="background-color:#f0f0f0;">
	<td>
	<big>Test the quality of parts before shipment</big>
	</td>
	<td align="center"><input type="radio" name="R1" value="0" /></td>
	<td align="center"><input type="radio" name="R1" value="1" /></td>
	<td align="center"><input type="radio" name="R1" value="2" /></td>
	<td align="center"><input type="radio" name="R1" value="3" /></td>
	<td align="center"><input type="radio" name="R1" value="4" /></td>
	</td>
	</tr>
	<tr style="background-color:#f0f0f0;">
	<td height="2px" colspan="6" />
	</tr>
	<tr>
	<td height="2px" colspan="6" />
	</tr>
	<tr>
	<td>
	<big>Study the structure of the human body</big>
	</td>
	<td align="center"><input type="radio" name="I1" value="0" /></td>
	<td align="center"><input type="radio" name="I1" value="1" /></td>
	<td align="center"><input type="radio" name="I1" value="2" /></td>
	<td align="center"><input type="radio" name="I1" value="3" /></td>
	<td align="center"><input type="radio" name="I1" value="4" /></td>
	</td>
	</tr>
	<tr>
	<td height="2px" colspan="6" />
	</tr>
	<tr style="background-color:#f0f0f0;">
	<td height="2px" colspan="6" />
	</tr>
	<tr style="background-color:#f0f0f0;">
	<td>
	<big>Conduct a musical choir</big>
	</td>
	<td align="center"><input type="radio" name="A1" value="0" /></td>
	<td align="center"><input type="radio" name="A1" value="1" /></td>
	<td align="center"><input type="radio" name="A1" value="2" /></td>
	<td align="center"><input type="radio" name="A1" value="3" /></td>
	<td align="center"><input type="radio" name="A1" value="4" /></td>
	
	</td>
	</tr>
	<tr style="background-color:#f0f0f0;">
	<td height="2px" colspan="6" />
	</tr>
	<tr>
	<td height="2px" colspan="6" />
	</tr>
	<tr>
	<td>
	<big>Give career guidance to people</big>
	</td>
	<td align="center"><input type="radio" name="S1" value="0" /></td>
	<td align="center"><input type="radio" name="S1" value="1" /></td>
	<td align="center"><input type="radio" name="S1" value="2" /></td>
	<td align="center"><input type="radio" name="S1" value="3" /></td>
	<td align="center"><input type="radio" name="S1" value="4" /></td>
	</td>
	</tr>
	<tr>
	<td height="2px" colspan="6" />
	</tr>
	<tr style="background-color:#f0f0f0;">
	<td height="2px" colspan="6" />
	</tr>
	<tr style="background-color:#f0f0f0;">
	<td>
	<big>Sell restaurant franchises to individuals</big>
	</td>
	<td align="center"><input type="radio" name="E1" value="0" /></td>
	<td align="center"><input type="radio" name="E1" value="1" /></td>
	<td align="center"><input type="radio" name="E1" value="2" /></td>
	<td align="center"><input type="radio" name="E1" value="3" /></td>
	<td align="center"><input type="radio" name="E1" value="4" /></td>
	</td>
	</tr>
	<tr style="background-color:#f0f0f0;">
	<td height="2px" colspan="6" />
	</tr>
	<tr>
	<td height="2px" colspan="6" />
	</tr>
	<tr>
	<td>
	<big>Generate the monthly payroll checks for an office</big>
	</td>
	<td align="center"><input type="radio" name="C1" value="0" /></td>
	<td align="center"><input type="radio" name="C1" value="1" /></td>
	<td align="center"><input type="radio" name="C1" value="2" /></td>
	<td align="center"><input type="radio" name="C1" value="3" /></td>
	<td align="center"><input type="radio" name="C1" value="4" /></td>
	</td>
	</tr>
	<tr>
	<td height="2px" colspan="6" />
	</tr>
	<tr style="background-color:#f0f0f0;">
	<td height="2px" colspan="6" />
	</tr>
	<tr style="background-color:#f0f0f0;">
	<td>
	<big>Lay brick or tile</big>
	</td>
	<td align="center"><input type="radio" name="R2" value="0" /></td>
	<td align="center"><input type="radio" name="R2" value="1" /></td>
	<td align="center"><input type="radio" name="R2" value="2" /></td>
	<td align="center"><input type="radio" name="R2" value="3" /></td>
	<td align="center"><input type="radio" name="R2" value="4" /></td>
	</td>
	</tr>
	<tr style="background-color:#f0f0f0;">
	<td height="2px" colspan="6" />
	</tr>
	<tr>
	<td height="2px" colspan="6" />
	</tr>
	<tr>
	<td>
	<big>Study animal behavior</big>
	</td>
	<td align="center"><input type="radio" name="I2" value="0" /></td>
	<td align="center"><input type="radio" name="I2" value="1" /></td>
	<td align="center"><input type="radio" name="I2" value="2" /></td>
	<td align="center"><input type="radio" name="I2" value="3" /></td>
	<td align="center"><input type="radio" name="I2" value="4" /></td>
	</td>
	</tr>
	<tr>
	<td height="2px" colspan="6" />
	</tr>
	<tr style="background-color:#f0f0f0;">
	<td height="2px" colspan="6" />
	</tr>
	<tr style="background-color:#f0f0f0;">
	<td>
	<big>Direct a play</big>
	</td>
	<td align="center"><input type="radio" name="A2" value="0" /></td>
	<td align="center"><input type="radio" name="A2" value="1" /></td>
	<td align="center"><input type="radio" name="A2" value="2" /></td>
	<td align="center"><input type="radio" name="A2" value="3" /></td>
	<td align="center"><input type="radio" name="A2" value="4" /></td>
	</td>
	</tr>
	<tr style="background-color:#f0f0f0;">
	<td height="2px" colspan="6" />
	</tr>
	<tr>
	<td height="2px" colspan="6" />
	</tr>
	<tr>
	<td>
	<big>Do volunteer work at a non-profit organization</big>
	</td>
	<td align="center"><input type="radio" name="S2" value="0" /></td>
	<td align="center"><input type="radio" name="S2" value="1" /></td>
	<td align="center"><input type="radio" name="S2" value="2" /></td>
	<td align="center"><input type="radio" name="S2" value="3" /></td>
	<td align="center"><input type="radio" name="S2" value="4" /></td>
	</td>
	</tr>
	<tr>
	<td height="2px" colspan="6" />
	</tr>
	<tr style="background-color:#f0f0f0;">
	<td height="2px" colspan="6" />
	</tr>
	<tr style="background-color:#f0f0f0;">
	<td>
	<big>Sell merchandise at a department store</big>
	</td>
	<td align="center"><input type="radio" name="E2" value="0" /></td>
	<td align="center"><input type="radio" name="E2" value="1" /></td>
	<td align="center"><input type="radio" name="E2" value="2" /></td>
	<td align="center"><input type="radio" name="E2" value="3" /></td>
	<td align="center"><input type="radio" name="E2" value="4" /></td>
	</td>
	<tr style="background-color:#f0f0f0;">
	<td height="2px" colspan="6" />
	</tr>
	<tr>
	<td height="2px" colspan="6" />
	</tr>
	<tr>
	<td>
	<big>Inventory supplies using a hand-held computer</big>
	</td>
	<td align="center"><input type="radio" name="C2" value="0" /></td>
	<td align="center"><input type="radio" name="C2" value="1" /></td>
	<td align="center"><input type="radio" name="C2" value="2" /></td>
	<td align="center"><input type="radio" name="C2" value="3" /></td>
	<td align="center"><input type="radio" name="C2" value="4" /></td>
	</td>
	</tr>
	
	<tr style="background-color:#f0f0f0;">
	<td>
	<big>Work on an offshore oil-drilling rig</big>
	</td>
	<td align="center"><input type="radio" name="R3" value="0" /></td>
	<td align="center"><input type="radio" name="R3" value="1" /></td>
	<td align="center"><input type="radio" name="R3" value="2" /></td>
	<td align="center"><input type="radio" name="R3" value="3" /></td>
	<td align="center"><input type="radio" name="R3" value="4" /></td>
	</td>
	</tr>
	<tr style="background-color:#f0f0f0;">
	<td height="2px" colspan="6" />
	</tr>
	<tr>
	<td height="2px" colspan="6" />
	</tr>
	<tr>
	<td>
	<big>Do research on plants or animals</big>
	</td>
	<td align="center"><input type="radio" name="I3" value="0" /></td>
	<td align="center"><input type="radio" name="I3" value="1" /></td>
	<td align="center"><input type="radio" name="I3" value="2" /></td>
	<td align="center"><input type="radio" name="I3" value="3" /></td>
	<td align="center"><input type="radio" name="I3" value="4" /></td>
	</td>
	</tr>
	<tr>
	<td height="2px" colspan="6" />
	</tr>
	<tr style="background-color:#f0f0f0;">
	<td height="2px" colspan="6" />
	</tr>
	<tr style="background-color:#f0f0f0;">
	<td>
	<big>Design artwork for magazines</big>
	</td>
	<td align="center"><input type="radio" name="A3" value="0" /></td>
	<td align="center"><input type="radio" name="A3" value="1" /></td>
	<td align="center"><input type="radio" name="A3" value="2" /></td>
	<td align="center"><input type="radio" name="A3" value="3" /></td>
	<td align="center"><input type="radio" name="A3" value="4" /></td>
	</td>
	</tr>
	<tr style="background-color:#f0f0f0;">
	<td height="2px" colspan="6" />
	</tr>
	<tr>
	<td height="2px" colspan="6" />
	</tr>
	<tr>
	<td>
	<big>Help people who have problems with drugs or alcohol</big>&nbsp;
	</td>
	<td align="center"><input type="radio" name="S3" value="0" /></td>
	<td align="center"><input type="radio" name="S3" value="1" /></td>
	<td align="center"><input type="radio" name="S3" value="2" /></td>
	<td align="center"><input type="radio" name="S3" value="3" /></td>
	<td align="center"><input type="radio" name="S3" value="4" /></td>
	</td>
	</tr>
	<tr>
	<td height="2px" colspan="6" />
	</tr>
	<tr style="background-color:#f0f0f0;">
	<td height="2px" colspan="6" />
	</tr>
	<tr style="background-color:#f0f0f0;">
	<td>
	<big>Manage the operations of a hotel</big>
	</td>
	<td align="center"><input type="radio" name="E3" value="0" /></td>
	<td align="center"><input type="radio" name="E3" value="1" /></td>
	<td align="center"><input type="radio" name="E3" value="2" /></td>
	<td align="center"><input type="radio" name="E3" value="3" /></td>
	<td align="center"><input type="radio" name="E3" value="4" /></td>
	</td>
	</tr>
	<tr style="background-color:#f0f0f0;">
	<td height="2px" colspan="6" />
	</tr>
	<tr>
	<td height="2px" colspan="6" />
	</tr>
	<tr>
	<td>
	<big>Use a computer program to generate customer bills</big>
	</td>
	<td align="center"><input type="radio" name="C3" value="0" /></td>
	<td align="center"><input type="radio" name="C3" value="1" /></td>
	<td align="center"><input type="radio" name="C3" value="2" /></td>
	<td align="center"><input type="radio" name="C3" value="3" /></td>
	<td align="center"><input type="radio" name="C3" value="4" /></td>
	</td>
	</tr>
	<tr>
	<td height="2px" colspan="6" />
	</tr>
	<tr style="background-color:#f0f0f0;">
	<td height="2px" colspan="6" />
	</tr>
	<tr style="background-color:#f0f0f0;">
	<td>
	<big>Assemble electronic parts</big>
	</td>
	<td align="center"><input type="radio" name="R4" value="0" /></td>
	<td align="center"><input type="radio" name="R4" value="1" /></td>
	<td align="center"><input type="radio" name="R4" value="2" /></td>
	<td align="center"><input type="radio" name="R4" value="3" /></td>
	<td align="center"><input type="radio" name="R4" value="4" /></td>
	</td>
	</tr>
	<tr style="background-color:#f0f0f0;">
	<td height="2px" colspan="6" />
	</tr>
	<tr>
	<td height="2px" colspan="6" />
	</tr>
	<tr>
	<td>
	<big>Develop a new medical treatment or procedure</big>
	</td>
	<td align="center"><input type="radio" name="I4" value="0" /></td>
	<td align="center"><input type="radio" name="I4" value="1" /></td>
	<td align="center"><input type="radio" name="I4" value="2" /></td>
	<td align="center"><input type="radio" name="I4" value="3" /></td>
	<td align="center"><input type="radio" name="I4" value="4" /></td>
	</td>
	</tr>
	<tr>
	<td height="2px" colspan="6" />
	</tr>
	<tr style="background-color:#f0f0f0;">
	<td height="2px" colspan="6" />
	</tr>
	<tr style="background-color:#f0f0f0;">
	<td>
	<big>Write a song</big>
	</td>
	<td align="center"><input type="radio" name="A4" value="0" /></td>
	<td align="center"><input type="radio" name="A4" value="1" /></td>
	<td align="center"><input type="radio" name="A4" value="2" /></td>
	<td align="center"><input type="radio" name="A4" value="3" /></td>
	<td align="center"><input type="radio" name="A4" value="4" /></td>
	</td>
	</tr>
	<tr style="background-color:#f0f0f0;">
	<td height="2px" colspan="6" />
	</tr>
	<tr>
	<td height="2px" colspan="6" />
	</tr>
	<tr>
	<td>
	<big>Teach an individual an exercise routine</big>
	</td>
	<td align="center"><input type="radio" name="S4" value="0" /></td>
	<td align="center"><input type="radio" name="S4" value="1" /></td>
	<td align="center"><input type="radio" name="S4" value="2" /></td>
	<td align="center"><input type="radio" name="S4" value="3" /></td>
	<td align="center"><input type="radio" name="S4" value="4" /></td>
	</td>
	</tr>
	<tr>
	<td height="2px" colspan="6" />
	</tr>
	<tr style="background-color:#f0f0f0;">
	<td height="2px" colspan="6" />
	</tr>
	<tr style="background-color:#f0f0f0;">
	<td>
	<big>Operate a beauty salon or barber shop</big>
	</td>
	<td align="center"><input type="radio" name="E4" value="0" /></td>
	<td align="center"><input type="radio" name="E4" value="1" /></td>
	<td align="center"><input type="radio" name="E4" value="2" /></td>
	<td align="center"><input type="radio" name="E4" value="3" /></td>
	<td align="center"><input type="radio" name="E4" value="4" /></td>
	</td>
	<tr style="background-color:#f0f0f0;">
	<td height="2px" colspan="6" />
	</tr>
	<tr>
	<td height="2px" colspan="6" />
	</tr>
	<tr>
	<td>
	<big>Maintain employee records</big>
	</td>
	<td align="center"><input type="radio" name="C4" value="0" /></td>
	<td align="center"><input type="radio" name="C4" value="1" /></td>
	<td align="center"><input type="radio" name="C4" value="2" /></td>
	<td align="center"><input type="radio" name="C4" value="3" /></td>
	<td align="center"><input type="radio" name="C4" value="4" /></td>
	</td>
	
	</tr>
	<tr>
	<td height="2px" colspan="6" />
	</tr>
	
	
	
	<tr style="background-color:#f0f0f0;">
	<td>
	<big>Operate a grinding machine in a factory</big>
	</td>
	<td align="center"><input type="radio" name="R5" value="0" /></td>
	<td align="center"><input type="radio" name="R5" value="1" /></td>
	<td align="center"><input type="radio" name="R5" value="2" /></td>
	<td align="center"><input type="radio" name="R5" value="3" /></td>
	<td align="center"><input type="radio" name="R5" value="4" /></td>
	</td>
	</tr>
	<tr style="background-color:#f0f0f0;">
	<td height="2px" colspan="6" />
	</tr>
	<tr>
	<td height="2px" colspan="6" />
	</tr>
	<tr>
	<td>
	<big>Conduct biological research</big>
	</td>
	<td align="center"><input type="radio" name="I5" value="0" /></td>
	<td align="center"><input type="radio" name="I5" value="1" /></td>
	<td align="center"><input type="radio" name="I5" value="2" /></td>
	<td align="center"><input type="radio" name="I5" value="3" /></td>
	<td align="center"><input type="radio" name="I5" value="4" /></td>
	</td>
	</tr>
	<tr>
	<td height="2px" colspan="6" />
	</tr>
	<tr style="background-color:#f0f0f0;">
	<td height="2px" colspan="6" />
	</tr>
	<tr style="background-color:#f0f0f0;">
	<td>
	<big>Write books or plays</big>
	</td>
	<td align="center"><input type="radio" name="A5" value="0" /></td>
	<td align="center"><input type="radio" name="A5" value="1" /></td>
	<td align="center"><input type="radio" name="A5" value="2" /></td>
	<td align="center"><input type="radio" name="A5" value="3" /></td>
	<td align="center"><input type="radio" name="A5" value="4" /></td>
	</td>
	</tr>
	<tr style="background-color:#f0f0f0;">
	<td height="2px" colspan="6" />
	</tr>
	<tr>
	<td height="2px" colspan="6" />
	</tr>
	<tr>
	<td>
	<big>Help people with family-related problems</big>
	</td>
	<td align="center"><input type="radio" name="S5" value="0" /></td>
	<td align="center"><input type="radio" name="S5" value="1" /></td>
	<td align="center"><input type="radio" name="S5" value="2" /></td>
	<td align="center"><input type="radio" name="S5" value="3" /></td>
	<td align="center"><input type="radio" name="S5" value="4" /></td>
	</td>
	</tr>
	<tr>
	<td height="2px" colspan="6" />
	</tr>
	<tr style="background-color:#f0f0f0;">
	<td height="2px" colspan="6" />
	</tr>
	<tr style="background-color:#f0f0f0;">
	<td>
	<big>Manage a department within a large company</big>
	</td>
	<td align="center"><input type="radio" name="E5" value="0" /></td>
	<td align="center"><input type="radio" name="E5" value="1" /></td>
	<td align="center"><input type="radio" name="E5" value="2" /></td>
	<td align="center"><input type="radio" name="E5" value="3" /></td>
	<td align="center"><input type="radio" name="E5" value="4" /></td>
	</td>
	</tr>
	<tr style="background-color:#f0f0f0;">
	<td height="2px" colspan="6" />
	</tr>
	<tr>
	<td height="2px" colspan="6" />
	</tr>
	<tr>
	<td>
	<big>Compute and record statistical and other numerical data</big>
	</td>
	<td align="center"><input type="radio" name="C5" value="0" /></td>
	<td align="center"><input type="radio" name="C5" value="1" /></td>
	<td align="center"><input type="radio" name="C5" value="2" /></td>
	<td align="center"><input type="radio" name="C5" value="3" /></td>
	<td align="center"><input type="radio" name="C5" value="4" /></td>
	</td>
	</tr>
	<tr>
	<td height="2px" colspan="6" />
	</tr>
	<tr style="background-color:#f0f0f0;">
	<td height="2px" colspan="6" />
	</tr>
	<tr style="background-color:#f0f0f0;">
	<td>
	<big>Fix a broken faucet</big>
	</td>
	<td align="center"><input type="radio" name="R6" value="0" /></td>
	<td align="center"><input type="radio" name="R6" value="1" /></td>
	<td align="center"><input type="radio" name="R6" value="2" /></td>
	<td align="center"><input type="radio" name="R6" value="3" /></td>
	<td align="center"><input type="radio" name="R6" value="4" /></td>
	</td>
	</tr>
	<tr style="background-color:#f0f0f0;">
	<td height="2px" colspan="6" />
	</tr>
	<tr>
	<td height="2px" colspan="6" />
	</tr>
	<tr>
	<td>
	<big>Study whales and other types of marine life</big>
	</td>
	<td align="center"><input type="radio" name="I6" value="0" /></td>
	<td align="center"><input type="radio" name="I6" value="1" /></td>
	<td align="center"><input type="radio" name="I6" value="2" /></td>
	<td align="center"><input type="radio" name="I6" value="3" /></td>
	<td align="center"><input type="radio" name="I6" value="4" /></td>
	</td>
	</tr>
	<tr>
	<td height="2px" colspan="6" />
	</tr>
	<tr style="background-color:#f0f0f0;">
	<td height="2px" colspan="6" />
	</tr>
	<tr style="background-color:#f0f0f0;">
	<td>
	<big>Play a musical instrument</big>
	</td>
	<td align="center"><input type="radio" name="A6" value="0" /></td>
	<td align="center"><input type="radio" name="A6" value="1" /></td>
	<td align="center"><input type="radio" name="A6" value="2" /></td>
	<td align="center"><input type="radio" name="A6" value="3" /></td>
	<td align="center"><input type="radio" name="A6" value="4" /></td>
	</td>
	</tr>
	<tr style="background-color:#f0f0f0;">
	<td height="2px" colspan="6" />
	</tr>
	<tr>
	<td height="2px" colspan="6" />
	</tr>
	<tr>
	<td>
	<big>Supervise the activities of children at a camp</big>
	</td>
	<td align="center"><input type="radio" name="S6" value="0" /></td>
	<td align="center"><input type="radio" name="S6" value="1" /></td>
	<td align="center"><input type="radio" name="S6" value="2" /></td>
	<td align="center"><input type="radio" name="S6" value="3" /></td>
	<td align="center"><input type="radio" name="S6" value="4" /></td>
	</td>
	</tr>
	<tr>
	<td height="2px" colspan="6" />
	</tr>
	<tr style="background-color:#f0f0f0;">
	<td height="2px" colspan="6" />
	</tr>
	<tr style="background-color:#f0f0f0;">
	<td>
	<big>Manage a clothing store</big>
	</td>
	<td align="center"><input type="radio" name="E6" value="0" /></td>
	<td align="center"><input type="radio" name="E6" value="1" /></td>
	<td align="center"><input type="radio" name="E6" value="2" /></td>
	<td align="center"><input type="radio" name="E6" value="3" /></td>
	<td align="center"><input type="radio" name="E6" value="4" /></td>
	</td>
	<tr style="background-color:#f0f0f0;">
	<td height="2px" colspan="6" />
	</tr>
	<tr>
	<td height="2px" colspan="6" />
	</tr>
	<tr>
	<td>
	<big>Operate a calculator</big>
	</td>
	<td align="center"><input type="radio" name="C6" value="0" /></td>
	<td align="center"><input type="radio" name="C6" value="1" /></td>
	<td align="center"><input type="radio" name="C6" value="2" /></td>
	<td align="center"><input type="radio" name="C6" value="3" /></td>
	<td align="center"><input type="radio" name="C6" value="4" /></td>
	</td>
	</tr>
	<tr>
	<td height="2px" colspan="6" />
	</tr>
	
	
	<tr style="background-color:#f0f0f0;">
	<td>
	<big>Assemble products in a factory</big>
	</td>
	<td align="center"><input type="radio" name="R7" value="0" /></td>
	<td align="center"><input type="radio" name="R7" value="1" /></td>
	<td align="center"><input type="radio" name="R7" value="2" /></td>
	<td align="center"><input type="radio" name="R7" value="3" /></td>
	<td align="center"><input type="radio" name="R7" value="4" /></td>
	</td>
	</tr>
	<tr style="background-color:#f0f0f0;">
	<td height="2px" colspan="6" />
	</tr>
	<tr>
	<td height="2px" colspan="6" />
	</tr>
	<tr>
	<td>
	<big>Work in a biology lab</big>
	</td>
	<td align="center"><input type="radio" name="I7" value="0" /></td>
	<td align="center"><input type="radio" name="I7" value="1" /></td>
	<td align="center"><input type="radio" name="I7" value="2" /></td>
	<td align="center"><input type="radio" name="I7" value="3" /></td>
	<td align="center"><input type="radio" name="I7" value="4" /></td>
	</td>
	</tr>
	<tr>
	<td height="2px" colspan="6" />
	</tr>
	<tr style="background-color:#f0f0f0;">
	<td height="2px" colspan="6" />
	</tr>
	<tr style="background-color:#f0f0f0;">
	<td>
	<big>Perform stunts for a movie or television show</big>
	</td>
	<td align="center"><input type="radio" name="A7" value="0" /></td>
	<td align="center"><input type="radio" name="A7" value="1" /></td>
	<td align="center"><input type="radio" name="A7" value="2" /></td>
	<td align="center"><input type="radio" name="A7" value="3" /></td>
	<td align="center"><input type="radio" name="A7" value="4" /></td>
	</td>
	</tr>
	<tr style="background-color:#f0f0f0;">
	<td height="2px" colspan="6" />
	</tr>
	<tr>
	<td height="2px" colspan="6" />
	</tr>
	<tr>
	<td>
	<big>Teach children how to read</big>
	</td>
	<td align="center"><input type="radio" name="S7" value="0" /></td>
	<td align="center"><input type="radio" name="S7" value="1" /></td>
	<td align="center"><input type="radio" name="S7" value="2" /></td>
	<td align="center"><input type="radio" name="S7" value="3" /></td>
	<td align="center"><input type="radio" name="S7" value="4" /></td>
	</td>
	</tr>
	<tr>
	<td height="2px" colspan="6" />
	</tr>
	<tr style="background-color:#f0f0f0;">
	<td height="2px" colspan="6" />
	</tr>
	<tr style="background-color:#f0f0f0;">
	<td>
    <big>Sell houses</big>
	</td>
	<td align="center"><input type="radio" name="E7" value="0" /></td>
	<td align="center"><input type="radio" name="E7" value="1" /></td>
	<td align="center"><input type="radio" name="E7" value="2" /></td>
	<td align="center"><input type="radio" name="E7" value="3" /></td>
	<td align="center"><input type="radio" name="E7" value="4" /></td>
	</td>
	</tr>
	<tr style="background-color:#f0f0f0;">
	<td height="2px" colspan="6" />
	</tr>
	<tr>
	<td height="2px" colspan="6" />
	</tr>
	<tr>
	<td>
	<big>Handle customers bank transactions</big>
	</td>
	<td align="center"><input type="radio" name="C7" value="0" /></td>
	<td align="center"><input type="radio" name="C7" value="1" /></td>
	<td align="center"><input type="radio" name="C7" value="2" /></td>
	<td align="center"><input type="radio" name="C7" value="3" /></td>
	<td align="center"><input type="radio" name="C7" value="4" /></td>
	</td>
	</tr>
	<tr>
	<td height="2px" colspan="6" />
	</tr>
	<tr style="background-color:#f0f0f0;">
	<td height="2px" colspan="6" />
	</tr>
	<tr style="background-color:#f0f0f0;">
	<td>
	<big>Install flooring in houses</big>
	</td>
	<td align="center"><input type="radio" name="R8" value="0" /></td>
	<td align="center"><input type="radio" name="R8" value="1" /></td>
	<td align="center"><input type="radio" name="R8" value="2" /></td>
	<td align="center"><input type="radio" name="R8" value="3" /></td>
	<td align="center"><input type="radio" name="R8" value="4" /></td>
	</td>
	</tr>
	<tr style="background-color:#f0f0f0;">
	<td height="2px" colspan="6" />
	</tr>
	<tr>
	<td height="2px" colspan="6" />
	</tr>
	<tr>
	<td>
	<big>Make a map of the bottom of an ocean</big>
	</td>
	<td align="center"><input type="radio" name="I8" value="0" /></td>
	<td align="center"><input type="radio" name="I8" value="1" /></td>
	<td align="center"><input type="radio" name="I8" value="2" /></td>
	<td align="center"><input type="radio" name="I8" value="3" /></td>
	<td align="center"><input type="radio" name="I8" value="4" /></td>
	</td>
	</tr>
	<tr>
	<td height="2px" colspan="6" />
	</tr>
	<tr style="background-color:#f0f0f0;">
	<td height="2px" colspan="6" />
	</tr>
	<tr style="background-color:#f0f0f0;">
	<td>
	<big>Design sets for plays</big>
	</td>
	<td align="center"><input type="radio" name="A8" value="0" /></td>
	<td align="center"><input type="radio" name="A8" value="1" /></td>
	<td align="center"><input type="radio" name="A8" value="2" /></td>
	<td align="center"><input type="radio" name="A8" value="3" /></td>
	<td align="center"><input type="radio" name="A8" value="4" /></td>
	</td>
	</tr>
	<tr style="background-color:#f0f0f0;">
	<td height="2px" colspan="6" />
	</tr>
	<tr>
	<td height="2px" colspan="6" />
	</tr>
	<tr>
	<td>
	<big>Help elderly people with their daily activities</big>
	</td>
	<td align="center"><input type="radio" name="S8" value="0" /></td>
	<td align="center"><input type="radio" name="S8" value="1" /></td>
	<td align="center"><input type="radio" name="S8" value="2" /></td>
	<td align="center"><input type="radio" name="S8" value="3" /></td>
	<td align="center"><input type="radio" name="S8" value="4" /></td>
	</td>
	</tr>
	<tr>
	<td height="2px" colspan="6" />
	</tr>
	<tr style="background-color:#f0f0f0;">
	<td height="2px" colspan="6" />
	</tr>
	<tr style="background-color:#f0f0f0;">
	<td>
	<big>Run a toy store</big>
	</td>
	<td align="center"><input type="radio" name="E8" value="0" /></td>
	<td align="center"><input type="radio" name="E8" value="1" /></td>
	<td align="center"><input type="radio" name="E8" value="2" /></td>
	<td align="center"><input type="radio" name="E8" value="3" /></td>
	<td align="center"><input type="radio" name="E8" value="4" /></td>
	</td>
	<tr style="background-color:#f0f0f0;">
	<td height="2px" colspan="6" />
	</tr>
	<tr>
	<td height="2px" colspan="6" />
	</tr>
	<tr>
	<td>
	<big>Keep shipping and receiving records</big>
	</td>
	<td align="center"><input type="radio" name="C8" value="0" /></td>
	<td align="center"><input type="radio" name="C8" value="1" /></td>
	<td align="center"><input type="radio" name="C8" value="2" /></td>
	<td align="center"><input type="radio" name="C8" value="3" /></td>
	<td align="center"><input type="radio" name="C8" value="4" /></td>
	</td>
	</tr>
	
	
	
	<tr>
	<td height="20px" />
	</tr>
	<tr>
	<td colspan="6" align="right">
	<center><input type="submit" value="Continue" style = "font-size:20px" onclick="javascript:return check();" /></center>

	<input id="complete" type="hidden" name="complete" value="0" />
	</tr>
	</table>

	 
</form>


		<!-- footer -->
		<div class="footer">
			<div class="footer_inner_info_w3ls_agileits">
				<div class="col-md-3 footer-left">
					<h2><a href="index.html"><i class="fa fa-clone" aria-hidden="true"></i> Career Hunt </a></h2>
					<p>Lorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora.</p>
					<ul class="social-nav model-3d-0 footer-social social two">
						<li>
							<a href="#" class="facebook">
								<div class="front"><i class="fa fa-facebook" aria-hidden="true"></i></div>
								<div class="back"><i class="fa fa-facebook" aria-hidden="true"></i></div>
							</a>
						</li>
						<li>
							<a href="#" class="twitter">
								<div class="front"><i class="fa fa-twitter" aria-hidden="true"></i></div>
								<div class="back"><i class="fa fa-twitter" aria-hidden="true"></i></div>
							</a>
						</li>
						<li>
							<a href="#" class="instagram">
								<div class="front"><i class="fa fa-instagram" aria-hidden="true"></i></div>
								<div class="back"><i class="fa fa-instagram" aria-hidden="true"></i></div>
							</a>
						</li>
						<li>
							<a href="#" class="pinterest">
								<div class="front"><i class="fa fa-linkedin" aria-hidden="true"></i></div>
								<div class="back"><i class="fa fa-linkedin" aria-hidden="true"></i></div>
							</a>
						</li>
					</ul>
				</div>
				<div class="col-md-9 footer-right">
					<div class="sign-grds">
					
					
						<div class="col-md-5 sign-gd-two">
							<h4>Contact <span>Information</span></h4>
							<div class="address">
								<div class="address-grid">
									<div class="address-left">
										<i class="fa fa-phone" aria-hidden="true"></i>
									</div>
									<div class="address-right">
										<h6>Phone Number</h6>
										<p>+91 93707 18105</p>
									</div>
									<div class="clearfix"> </div>
								</div>
								<div class="address-grid">
									<div class="address-left">
										<i class="fa fa-envelope" aria-hidden="true"></i>
									</div>
									<div class="address-right">
										<h6>Email Address</h6>
										<p>Email :<a href="mailto:tejaskhandage@gmail.com"> tejaskhandage@gmail.com</a></p>
									</div>
									<div class="clearfix"> </div>
								</div>
								<div class="address-grid">
									<div class="address-left">
										<i class="fa fa-map-marker" aria-hidden="true"></i>
									</div>
									<div class="address-right">
										<h6>Location</h6>
										<p>Jaihind Polytechnic Kuran
	
										</p>
									</div>
									<div class="clearfix"> </div>
								</div>
							</div>
						</div>
	
						<div class="clearfix"></div>
					</div>
				</div>
				<div class="clearfix"></div>
				<p class="copy-right">Design by : Tejas Vikas Khandage</p>
			</div>
		</div>
		</div>
		<!-- //footer -->
	<!-- //footer -->
	<script type="text/javascript" src="js/jquery-2.2.3.min.js"></script>
	<script type="text/javascript" src="js/bootstrap.js"></script>
	<script>
		$('ul.dropdown-menu li').hover(function () {
			$(this).find('.dropdown-menu').stop(true, true).delay(200).fadeIn(500);
		}, function () {
			$(this).find('.dropdown-menu').stop(true, true).delay(200).fadeOut(500);
		});
	</script>

	<!-- js -->
	<!-- Smooth-Scrolling-JavaScript -->
	<script type="text/javascript" src="js/easing.js"></script>
	<script type="text/javascript" src="js/move-top.js"></script>
	<script type="text/javascript">
		jQuery(document).ready(function ($) {
			$(".scroll, .navbar li a, .footer li a").click(function (event) {
				$('html,body').animate({
					scrollTop: $(this.hash).offset().top
				}, 1000);
			});
		});
	</script>
	<!-- //Smooth-Scrolling-JavaScript -->
	<script type="text/javascript">
		$(document).ready(function () {
		

			$().UItoTop({
				easingType: 'easeOutQuart'
			});

		});
	</script>
	<a href="#home" class="scroll" id="toTop" style="display: block;"> <span id="toTopHover" style="opacity: 1;"> </span></a>
	<!-- jQuery-Photo-filter-lightbox-Gallery-plugin -->
	<script type="text/javascript" src="js/jquery-1.7.2.js"></script>
	<script src="js/jquery.quicksand.js" type="text/javascript"></script>
	<script src="js/script.js" type="text/javascript"></script>
	<script src="js/jquery.prettyPhoto.js" type="text/javascript"></script>
	<!-- //jQuery-Photo-filter-lightbox-Gallery-plugin -->
</body>

</html>